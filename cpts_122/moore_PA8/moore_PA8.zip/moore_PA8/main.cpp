/*******************************************************************************************
Programmer: Devin Moore
Date:       2021/04/12
Class:      CptS122 Section 10 Andrew O'Fallon
TA:			Muthuu Svs
Assignment: PA8 Data Analysis with BSTs

Description: This PA is to make a BST and print it and do other things with polymorphism and whatever
*******************************************************************************************/
#include "DataAnalysis.h"

int main(void)
{
	DataAnalysis newAnalysis;
	
	newAnalysis.runAnalysis();

	return 0;
}