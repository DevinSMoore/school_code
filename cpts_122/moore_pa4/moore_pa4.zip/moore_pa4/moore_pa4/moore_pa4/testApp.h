#pragma once
#include "dietPlan.h"

class Test
{
public:
	void testEditGoal(void);
	void testDietListCopyAssignmentOperator(void);
	void testFstreamInsertionOverload(void);
	void testLoadWeeklyPlan(void);
	void testStoreDayPlan(void);

	void testExerciseListCopyAssignmentOperator(void);
	void testFstreamInsertionOverloadEx(void);
	void testLoadWeeklyPlanEx(void);
	void testStoreWeeklyPlanEx(void);
	void testStoreDayExercisePlan(void);

private:


};