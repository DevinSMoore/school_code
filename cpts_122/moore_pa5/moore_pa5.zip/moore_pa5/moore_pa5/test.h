#pragma once

class Test
{
public:
	void testEnqueueEmpty(void);
	void testEnqueueOneNode(void);
	void testDequeueOneNode(void);
	void testDequeueTwoNode(void);
	void case24Hours(void);

private:

};